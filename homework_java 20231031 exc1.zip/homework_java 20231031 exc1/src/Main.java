import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(" Введите 1 слово состоящее из четного количества букв: ");
        String firstWord = scanner.next();
        System.out.println(" Введите 2 слово состоящее из четного количества букв: ");
        String secondWord = scanner.next();

        if (firstWord.length() % 2 == 0 && (secondWord.length() % 2) == 0) {
            String thirdWord = (firstWord.substring(0,firstWord.length()/2)) +
                    (secondWord.substring(secondWord.length()/2,secondWord.length()));
            System.out.println(thirdWord);

        } else {
            System.out.println("Введите слова с четным количеством букв");
        }
    }
}

// 1 уровень сложности: Задание 1. Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв (проверьте количество букв в слове).
//Нужно получить слово, состоящее из первой половины первого слова и второй половины второго слова. распечатать на консоль.
//Например: ввод - mama, papa. Вывод – mapa